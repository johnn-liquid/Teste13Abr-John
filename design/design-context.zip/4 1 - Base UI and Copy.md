---
layer: design-system
question: What are the base styling and microcopy rules for Liquid OS?
---

# 4.1 - Base UI and Copy

## 1. Visual Foundation
*   **ShadCN Vanilla:** UI is built on ShadCN/ui without significant divergence. Customization shifts consistency responsibility to the designer and away from the agent.
*   **Dark Mode Only:** LuriDS is dark mode only. No light mode fallback. All generated screens use dark mode tokens.
*   **Tokens:** All values are semantic tokens (OKLCH color space). Hardcoded hex values or sizes are prohibited.
*   **Motion:** Motion communicates state changes only (e.g., thinking vs executing). Never animate for decoration. The default is stillness.

## 2. Tone of Voice
*   **Core Rule:** Say what happened, say what to do next, stop. The system is professional, direct, and non-emotional.
*   **Prohibited Preamble:** Never use "Oops!", "Great!", "I'd be happy to help", or exclamation marks in informational copy.
*   **Pronouns:** System messages use 1st person plural ("We couldn't load"). Instructions use 2nd person ("Review policy"). Agent messages use 1st person singular. CTAs use imperative without subject ("Approve").

## 3. Interfaces & State Copy
*   **Buttons:** Verb + object (max 3 words). Use precise verbs (Delete, Revoke, Disconnect).
*   **Errors:** State what failed (specific) + what to do (recovery path). Never use generic "Something went wrong".
*   **Empty State:** State what is missing + offer path to add it.
*   **Confirmation Dialogs:** Action + consequence if executed + consequence if rejected. Must be concrete.
*   **Loading:** Use Skeleton or Spinner components. Never use text "Loading...".
